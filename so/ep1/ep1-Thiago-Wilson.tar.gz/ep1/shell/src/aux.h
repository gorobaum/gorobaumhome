
#ifndef AUX_H_
#define AUX_H_

char* copy_string(const char *src);

#endif

