O algoritmo da função isPrime foi testada usando o primo de número 1000001
( 15485867 ) obtido atráves do site http://www.bigprimes.net. Como essa função
usa a lista de primos, a lista foi testada junto com a função, pois se a lista
estivesse errada a função tambem estaria. Tambem testamos com um vetor de 1 até
100, com o seguinte resultado:
[False,True,True,False,True,False,True,False,False,False,True,False,True,False,
 False,False,True,False,True,False,False,False,True,False,False,False,False,False,
 True,False,True,False,False,False,False,False,True,False,False,False,True,False,
 True,False,False,False,True,False,False,False,False,False,True,False,False,False,
 False,False,True,False,True,False,False,False,False,False,True,False,False,False,
 True,False,True,False,False,False,False,False,True,False,False,False,True,False,
 False,False,False,False,True,False,False,False,False,False,False,False,True,False,
 False,False]
Ao pedir o primo da posi��o 100000, obtivemos 1299721, que � o correto.

A função lcsLength foi testada com os seguintes valores e resultados:
"Macaco" "Voador" = 2
"AAAAAAAAAA" "AAAAAAAAAAAAB" = 10
"ABACATE" "ABABACATEE" = 7
